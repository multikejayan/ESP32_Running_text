#pragma GCC error "SmartLEDShieldV4.h is isn't supported as of SmartMatrix Library 4.0, use #include <MatrixHardware_Teensy3_ShieldV4.h> at the top of your sketch instead"
